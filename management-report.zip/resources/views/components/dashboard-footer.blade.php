<div>
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Dibuat oleh Divisi IT KPA
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2024 <a href="https://ecoasphalt.id/">ECOASPHALT ID</a>.</strong> All rights
    reserved.
</div>
